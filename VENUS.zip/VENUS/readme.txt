Para cada Maquina diferente trocar a porta R:127.0.0.1:1080 para o intervalo de 1080 até 1090

PC1) venus.exe client https://lobster.cwdlab.com R:127.0.0.1:1080:socks
PC2) venus.exe client https://lobster.cwdlab.com R:127.0.0.1:1081:socks
PC3) venus.exe client https://lobster.cwdlab.com R:127.0.0.1:1082:socks